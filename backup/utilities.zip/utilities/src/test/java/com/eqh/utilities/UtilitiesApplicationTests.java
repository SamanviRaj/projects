package com.eqh.utilities;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtilitiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
